<?php
// $Id: views-slideshow-ddblock-pager-content.tpl.php,v 1.1 2010/08/05 07:52:03 antsin Exp $

/**
 * @file
 * Dynamic display block module template: pager template
 *
 */
 ?>
